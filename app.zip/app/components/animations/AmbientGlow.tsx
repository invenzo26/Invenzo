'use client'

import { motion } from 'framer-motion'

export default function AmbientGlow() {
  return (
    <>
      {/* Top Right */}
      <motion.div
        animate={{
          x: [0, 60, -30, 0],
          y: [0, -40, 30, 0],
          scale: [1, 1.1, 0.95, 1],
        }}
        transition={{
          duration: 28,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="fixed top-[-200px] right-[-200px] w-[650px] h-[650px] rounded-full blur-[140px] pointer-events-none z-0"
        style={{
          background:
            'radial-gradient(circle,var(--gold-primary),transparent 70%)',
          opacity: 0.08,
        }}
      />

      {/* Bottom Left */}
      <motion.div
        animate={{
          x: [0, -50, 40, 0],
          y: [0, 30, -20, 0],
          scale: [1, 0.95, 1.08, 1],
        }}
        transition={{
          duration: 34,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="fixed bottom-[-220px] left-[-180px] w-[550px] h-[550px] rounded-full blur-[130px] pointer-events-none z-0"
        style={{
          background:
            'radial-gradient(circle,var(--gold-primary),transparent 70%)',
          opacity: 0.05,
        }}
      />
    </>
  )
}